# face-api-detection
Face detection using Face-api.js and vanilla JavaScript
